These are the figures I drew to illustrate Kiran Kedlaya's book "Geometry Unbound":
http://math.mit.edu/~kedlaya/geometryunbound/

I used R. Grothmann's free program "Compass and Ruler", which can be found here:
http://mathsrv.ku-eichstaett.de/MGF/homes/grothmann/java/zirkel/doc_en/index.html

Many thanks to those people who make easier to appreciate geometry.

That's all. And that's free, obviously... you can use, edit, copy, or do whatever you want 
with this figures.


Andrea Fogari, from Italy. mailto: edriv@email.it

(version 1 - 11th november 2006)
